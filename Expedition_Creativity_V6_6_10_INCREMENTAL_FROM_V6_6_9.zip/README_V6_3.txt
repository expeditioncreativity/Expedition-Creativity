Expedition Creativity V6.3

Hero fold optimization:
- Less margin above the logo
- Smaller hero logo on desktop
- Reduced vertical spacing
- First hero section should fit better in the first viewport without scrolling
