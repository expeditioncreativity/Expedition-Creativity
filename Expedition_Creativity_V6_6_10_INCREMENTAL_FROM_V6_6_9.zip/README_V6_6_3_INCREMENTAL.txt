Expedition Creativity V6.6.3 incremental from V6.6.2

- Navbar logo replaced with provided Expedition Creativity logo asset and made visible on the gold navigation bar.
- Fixed card ordering so tags appear above descriptions consistently.
- Tightened Tracks page header/filter spacing.
- Updated Tracks intro line to: 8 expeditions, 5 worlds, one creative journey.
- Normalized card spacing on Tracks page and Home carousel.
- Expanded filter buttons from all visible and data tags, including Film Scoring where present.

Note: YouTube view counts are not included as live data; they require the YouTube Data API or periodic manual updates.
