Expedition Creativity V6.6 incremental from V6.5

Implemented:
- Corrected email to hello@expeditioncreativity.com across HTML/mailto/follow panel.
- Added About page and About navigation link.
- Made navigation bar more prominent with gold background and blue hover contrast.
- Added branded YouTube, LinkedIn and email buttons.
- Expanded Journey copy with French horn, 15 years in a local band, film music passion and composer references.
- Adjusted Journey layout to emphasize text and make the quote more compact.
- Added Home track tag chips aligned with Tracks page themes.
- Added automatic 5-second horizontal carousel behaviour for track rails, paused on hover/touch.
